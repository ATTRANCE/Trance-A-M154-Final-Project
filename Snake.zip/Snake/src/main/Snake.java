package main;

import javax.swing.*;
import java.awt.*;
import java.awt.event.WindowEvent;
import java.util.ArrayList;


import static main.Rectangle.rec_height;
import static main.Rectangle.rec_width;


public class Snake extends JPanel { //It extends JPanel because we will be drawing the objects to the screen//

    //These lines of code is for the graphics and mechanics of the snake:
    private static final Color c = new Color(120,168,190);
    private static final int start = 250;
    private static final int speed = 25;

    private ArrayList<Rectangle> body;

    private String direction;

    private Apple apple;

    private Main window;


    //This block passes the details of the snake from the "Main" class
    public Snake(main.Main window) {
        this.window = window;
        this.body = new ArrayList<>();
        body.add(new Rectangle(start, start));
        Rectangle last = this.body.get(0);
        body.add(new Rectangle(last.getX_axis() - rec_width, last.getY_axis()));
        Rectangle last_2 = this.body.get(1);
        body.add(new Rectangle(last_2.getX_axis() - rec_width, last_2.getY_axis()));
        this.direction = "right";
    }

    //These blocks of codes is for the mechanics of moving the snake in left, right, downward, or upward directions:
    public void setDirection(String direction) {
        this.direction = direction;
    }
    public String getDirection() {
        return this.direction;
    }

    //This block is for adding another rectangle to the body, opposite the direction of the snake, once it eats an apple:
    public void addPart() {
        Rectangle last = this.body.get(this.body.size() -1);
        switch (this.direction) {
            case "right" -> this.body.add(new Rectangle(last.getX_axis() - rec_width, last.getY_axis()));
            case "left" -> this.body.add(new Rectangle(last.getX_axis() + rec_width, last.getY_axis()));
            case "up" -> this.body.add(new Rectangle(last.getX_axis() , last.getY_axis() + rec_width));
            case "down" -> this.body.add(new Rectangle(last.getX_axis(), last.getY_axis()  - rec_width));
        }
    }

    //This block will check for collisions based on the "boolean intersects" function in the Rectangle class
    public void checkColission() {
        Rectangle r3 = this.body.get(0);
        for (int i = 1; i < this.body.size(); i++) {
            Rectangle r2 = this.body.get(i);
            
            //This block will end the game if the head of the snake collides with any part of its body
            if (r3.intersects(r2)) {
                System.out.println("You lose!");
                this.window.setVisible(false);

                JFrame parent = new JFrame("Game over!");
                JOptionPane.showMessageDialog(parent, "Your score: " + this.body.size());

                this.window.dispatchEvent(new WindowEvent(this.window, WindowEvent.WINDOW_CLOSING));
                System.exit(0);
            }
        }
        
        //This block will add a new apple once there is no collision
        if (this.apple != null) {
            if (r3.intersects(new Rectangle(this.apple.getX_axis(),this.apple.getY_axis()))) {
                this.apple = null;
                this.addPart();
            }
        }

    }

    //This block is for the movement of the snake
    public void moveSnake() {

        //This array is for storing the new position of the snake
        ArrayList<Rectangle> newLst = new ArrayList<>();

        //These lines of code is concerned with the rectangles that make up the snake
        Rectangle first = this.body.get(0);//This is basically the head
        Rectangle head = new Rectangle(first.getX_axis(), first.getY_axis());
        
        //This block is for the movement of the head of the snake
        switch (this.direction) {
            case "right" -> head.setX_axis(speed);
            case "left" -> head.setX_axis(-speed);
            case "up" -> head.setY_axis(-speed);
            case "down" -> head.setY_axis(speed);
        }
        newLst.add(head);//We add a new head to the list

        //This block will allow the newly added rectangles to move towards the direction of the rectangle that precedes them
        for (int i = 1; i < this.body.size(); i++) {
            Rectangle previous = this.body.get(i-1);
            Rectangle newRec = new Rectangle(previous.getX_axis(), previous.getY_axis());
            newLst.add(newRec);
        }


        //This will check for the collision
        this.body = newLst;
        checkColission();
    }

    //This block is for the graphics of the game:
    private void drawSnake(Graphics g) {
        moveSnake();

        //This line will draw moved snake
        Graphics2D g2d = (Graphics2D) g;


        //This block draws the apple
        if (this.apple != null) {
            g2d.setPaint(Color.red);
            g2d.drawRect(this.apple.getX_axis(), this.apple.getY_axis(), rec_width, rec_height);
            g2d.fillRect(this.apple.getX_axis(),this.apple.getY_axis(),rec_width,rec_height);
        }

        //This block draws a new rectangle as a part of the body of the snake for every apple eaten
        g2d.setPaint(Color.blue);
        for (Rectangle rec: this.body) {
            g2d.drawRect(rec.getX_axis(),rec.getY_axis(),rec_width,rec_height);
            g2d.fillRect(rec.getX_axis(),rec.getY_axis(),rec_width,rec_height);
        }
    }

    public void setApple(Apple apple) {
        this.apple = apple;
    }

    public Apple getApple() {
        return this.apple;
    }

    @Override
    public void paintComponent(Graphics g) {
        super.paintComponent(g);
        setBackground(c);
        drawSnake(g);
    }
}
