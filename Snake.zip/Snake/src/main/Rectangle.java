package main;

//The snake will be composed of Rectangles
public class Rectangle {

    //These tells us that the game is a 2-Dimensional game with x and y-coordinates
    private int x_axis;
    private int y_axis;

    //These lines of codes determines the size of the snake
    public static final int rec_width = 25;
    public static final int rec_height = 25;
    
    //This block helps us to create rectangles which will form the body of the snake
    public Rectangle(int x_axis, int y_axis) {
        this.x_axis = x_axis;
        this.y_axis = y_axis;
    }
    
    //This block will check for intersection between triangles which will mean that the game is over
    public boolean intersects(Rectangle r2) {
        /*
        return true if x and y coordinates of
        this and r2 are the same
        */
        return this.x_axis == r2.getX_axis() && this.y_axis == r2.getY_axis();
    }

    //These lines of codes will help us access the position of the snake and check for intersections
    public int getX_axis() {
        return this.x_axis;
    }

    public int getY_axis() {
        return this.y_axis;
    }
    //These lines of code will help us move the snake in the direction that we want it to move to
    public void setX_axis(int increment) { this.x_axis = this.x_axis + increment; }

    public void setY_axis(int increment) { this.y_axis =  this.y_axis + increment; }


}

