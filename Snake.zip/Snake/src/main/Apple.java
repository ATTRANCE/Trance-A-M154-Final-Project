package main;

import java.util.Random;
import java.util.TimerTask;

public class Apple extends TimerTask {

    //These two lines of codes will be the position of the Apple in the screen
    private int x_axis;
    private int y_axis;
    
    //This line of code is our reference to the position of the snake
    private Snake snake;

    //These lines of code enables us to get the position of the apple through x and y-coordinates
    public int getX_axis() {
        return x_axis;
    }

    public int getY_axis() {
        return y_axis;
    }
    
    //This block helps us to create the apple that the snake will eat
    public Apple(Snake snake) {
        this.snake = snake;
    }
    
    //This block helps us to set the position of the apple
    public Apple() {
        this.x_axis = 25 * new Random().nextInt(20);
        this.y_axis = 25 * new Random().nextInt(20);
    }
    
    //This block enables the program to create an apple when the previous apple is already eaten by the snake
    @Override
    public void run() {
        if (this.snake.getApple() == null) {
            this.snake.setApple(new Apple());
        }
    }
}

